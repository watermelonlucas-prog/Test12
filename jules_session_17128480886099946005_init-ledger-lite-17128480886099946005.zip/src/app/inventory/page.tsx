'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { AlertCircle } from 'lucide-react';

interface InventoryItem {
  id: string;
  item_name: string;
  unit_cost: number;
  selling_price: number;
  stock_quantity: number;
  reorder_threshold: number;
}

export default function InventoryPage() {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchInventory = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('inventory')
      .select('*')
      .order('item_name', { ascending: true });
    
    if (error) {
      console.error('Error fetching inventory:', error);
    } else {
      setInventory(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('inventory')
        .select('*')
        .order('item_name', { ascending: true });
      if (mounted) {
        if (error) {
          console.error('Error fetching inventory:', error);
        } else {
          setInventory(data || []);
        }
        setLoading(false);
      }
    };
    load();
    return () => { mounted = false; };
  }, []);

  const handleSell = async (item: InventoryItem) => {
    if (item.stock_quantity <= 0) return;

    // 1. Reduce stock
    const newStock = item.stock_quantity - 1;
    const { error: updateError } = await supabase
      .from('inventory')
      .update({ stock_quantity: newStock })
      .eq('id', item.id);

    if (updateError) {
      console.error('Failed to update stock:', updateError);
      return;
    }

    // 2. Record Transaction (Income)
    await supabase.from('transactions').insert([{
      type: 'income',
      amount: item.selling_price,
      category: 'Sales',
      description: `Sold 1x ${item.item_name}`,
      transaction_date: new Date().toISOString().split('T')[0]
    }]);

    // 3. Record Transaction (COGS Expense)
    await supabase.from('transactions').insert([{
      type: 'expense',
      amount: item.unit_cost,
      category: 'Cost of Goods Sold',
      description: `COGS for 1x ${item.item_name}`,
      transaction_date: new Date().toISOString().split('T')[0]
    }]);

    fetchInventory();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Inventory Management</h1>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 text-sm font-medium shadow-sm">
          Add Item
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full text-center py-10 text-gray-500">Loading inventory...</div>
        ) : inventory.length === 0 ? (
          <div className="col-span-full text-center py-10 text-gray-500">No inventory items found. Add some to get started!</div>
        ) : (
          inventory.map((item) => (
            <div key={item.id} className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 flex flex-col h-full">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{item.item_name}</h3>
                {item.stock_quantity <= item.reorder_threshold && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                    <AlertCircle className="w-3 h-3" />
                    Low Stock
                  </span>
                )}
              </div>
              
              <div className="space-y-2 flex-grow">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Stock</span>
                  <span className={`font-medium ${item.stock_quantity <= item.reorder_threshold ? 'text-red-600' : 'text-gray-900'}`}>
                    {item.stock_quantity} units
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Cost/Unit</span>
                  <span className="text-gray-900">${item.unit_cost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Selling Price</span>
                  <span className="text-gray-900">${item.selling_price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Margin</span>
                  <span className="text-green-600 font-medium">
                    ${(item.selling_price - item.unit_cost).toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-100">
                <button
                  onClick={() => handleSell(item)}
                  disabled={item.stock_quantity <= 0}
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Record Sale (1 unit)
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
