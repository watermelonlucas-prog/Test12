'use client';

import { jsPDF } from 'jspdf';
import Papa from 'papaparse';
import { supabase } from '@/lib/supabase';
import { useState } from 'react';

export function ExportButton() {
  const [loading, setLoading] = useState(false);

  const fetchExportData = async () => {
    const { data: transactions } = await supabase.from('transactions').select('*').order('transaction_date', { ascending: true });
    const { data: inventory } = await supabase.from('inventory').select('*');
    return { transactions: transactions || [], inventory: inventory || [] };
  };

  const exportCSV = async () => {
    setLoading(true);
    try {
      const { transactions } = await fetchExportData();
      if (transactions.length === 0) {
        alert('No transactions to export.');
        return;
      }
      
      const csv = Papa.unparse(transactions.map(t => ({
        Date: t.transaction_date,
        Type: t.type,
        Category: t.category,
        Description: t.description,
        Amount: t.amount
      })));
      
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'ledger-export.csv';
      link.click();
    } finally {
      setLoading(false);
    }
  };

  const exportPDF = async () => {
    setLoading(true);
    try {
      const { transactions, inventory } = await fetchExportData();
      
      const doc = new jsPDF();
      doc.setFontSize(20);
      doc.text('LedgerLite Financial Summary', 14, 22);
      
      doc.setFontSize(12);
      let y = 35;
      
      const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
      const expenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
      const net = income - expenses;
      
      doc.text(`Total Income: $${income.toFixed(2)}`, 14, y);
      y += 10;
      doc.text(`Total Expenses: $${expenses.toFixed(2)}`, 14, y);
      y += 10;
      doc.text(`Net Flow: $${net.toFixed(2)}`, 14, y);
      y += 20;

      doc.setFontSize(16);
      doc.text('Inventory Status', 14, y);
      y += 10;
      
      doc.setFontSize(10);
      inventory.forEach(item => {
        if (y > 280) {
          doc.addPage();
          y = 20;
        }
        doc.text(`${item.item_name} - Stock: ${item.stock_quantity} (Cost: $${item.unit_cost}, Price: $${item.selling_price})`, 14, y);
        y += 8;
      });

      doc.save('ledger-summary.pdf');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex space-x-4">
      <button
        onClick={exportCSV}
        disabled={loading}
        className="px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
      >
        Export CSV
      </button>
      <button
        onClick={exportPDF}
        disabled={loading}
        className="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
      >
        Export PDF Report
      </button>
    </div>
  );
}
