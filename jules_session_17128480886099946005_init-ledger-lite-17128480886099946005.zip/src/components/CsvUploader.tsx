'use client';

import { useState } from 'react';
import Papa from 'papaparse';
import { supabase } from '@/lib/supabase';

// Simple Keyword Rule Engine
const categorizeDescription = (description: string): string => {
  const desc = description.toLowerCase();
  if (desc.includes('staples') || desc.includes('print')) return 'Office Supplies';
  if (desc.includes('inventory') || desc.includes('supplier') || desc.includes('wholesale')) return 'Cost of Goods Sold';
  if (desc.includes('uber') || desc.includes('lyft') || desc.includes('transit')) return 'Transportation';
  if (desc.includes('restaurant') || desc.includes('cafe') || desc.includes('food')) return 'Meals';
  return 'Uncategorized';
};

export function CsvUploader({ onSuccess }: { onSuccess?: () => void }) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setMessage('');

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const transactions = results.data.map((r: unknown) => {
            const row = r as Record<string, string | number | undefined>;
            // Basic mapping assumption, adjust based on actual CSV format
            const description = String(row.Description || row.description || '');
            const amountStr = String(row.Amount || row.amount || '0');
            const amount = parseFloat(amountStr);
            const type = amount >= 0 ? 'income' : 'expense';
            const category = categorizeDescription(description);
            const date = String(row.Date || row.date || new Date().toISOString().split('T')[0]);

            return {
              type,
              amount: Math.abs(amount),
              category,
              description,
              transaction_date: date,
            };
          });

          if (transactions.length > 0) {
            const { error } = await supabase.from('transactions').insert(transactions);
            if (error) throw error;
            setMessage(`Successfully imported ${transactions.length} transactions.`);
            if (onSuccess) onSuccess();
          } else {
            setMessage('No valid transactions found in CSV.');
          }
        } catch (error: unknown) {
          setMessage(`Error importing: ${error instanceof Error ? error.message : String(error)}`);
        } finally {
          setLoading(false);
        }
      },
      error: (error) => {
        setMessage(`CSV Parsing Error: ${error.message}`);
        setLoading(false);
      }
    });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
      <h2 className="text-lg font-semibold mb-4">Upload Transactions (CSV)</h2>
      <div className="mt-2 flex justify-center rounded-md border-2 border-dashed border-gray-300 px-6 pt-5 pb-6">
        <div className="space-y-1 text-center">
          <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
            <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <div className="flex text-sm text-gray-600 justify-center">
            <label htmlFor="file-upload" className="relative cursor-pointer rounded-md bg-white font-medium text-blue-600 focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-500 focus-within:ring-offset-2 hover:text-blue-500">
              <span>Upload a file</span>
              <input id="file-upload" name="file-upload" type="file" accept=".csv" className="sr-only" onChange={handleFileUpload} disabled={loading} />
            </label>
          </div>
          <p className="text-xs text-gray-500">CSV up to 10MB</p>
        </div>
      </div>
      {message && <p className="mt-4 text-sm text-gray-700 text-center">{message}</p>}
    </div>
  );
}
